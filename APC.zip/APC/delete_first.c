#include <stdio.h>
#include <stdlib.h>
#include "apc.h"
/* Used when modifying the list */
int dl_delete_first(Dlist **head, Dlist **tail)
{
    if (*head == NULL) // Check if the list is empty
    {
        return FAILURE;
    }

    if (*head == *tail) // Single node in the list
    {
        free(*head);
        *head = NULL;
        *tail = NULL;
        return SUCCESS;
    }

    Dlist *temp = *head;
    *head = (*head)->next;
    (*head)->prev = NULL;
    free(temp);
    return SUCCESS;
}