#include <stdio.h>
#include <stdlib.h>
#include "apc.h"
/* Called when 'x'  operator is used */
Dlist *headR = NULL, *tailR = NULL;

int multiplication(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2, Dlist **headR1,Dlist **tailR1, Dlist **headR2,Dlist **tailR2)
{
	Dlist *temp1 = *tail1;
	Dlist *temp2 = *tail2;
	int carry = 0; 
	int count = 0;
	while (temp2 != NULL) 
	{
		for (int i = 0; i < count; i++)
		{
			dl_insert_first(headR2, tailR2, 0);
		}
		while (temp1 != NULL) 
		{
			if (temp2 -> next == NULL) 
			{
				int data = temp1 -> data * temp2 -> data + carry; 
				if (data > 9)
				{ 
					dl_insert_first(headR1, tailR1, (data % 10));
					carry = data / 10;
				}
				else
				{
					dl_insert_first(headR1, tailR1, data); 
					carry = 0;
				}
			}
			else
			{
				int data = temp1 -> data * temp2 -> data + carry;
				if (data > 9)
				{ 
					dl_insert_first(headR2, tailR2, (data % 10));
					carry = data / 10;
				}
				else
				{
					dl_insert_first(headR2, tailR2, data);
					carry = 0;
				}
			}
			temp1 = temp1 -> prev;
		}
		if (carry != 0 && temp2 -> next == NULL)
		{
			dl_insert_first(headR1, tailR1, carry);
			carry = 0;
		}
		else if (carry != 0)
		{
			dl_insert_first(headR2, tailR2, carry);
			carry = 0;
		}
		if (temp2 -> next != NULL)
		{
			multiplication_addition(headR1, tailR1, headR2, tailR2, &headR, &tailR);
			dl_delete_list(headR1, tailR1);
			dl_delete_list(headR2, tailR2);
			*headR1 = headR;
			*tailR1 = tailR;
			headR = NULL;
			tailR = NULL;
		}
		count++;
		temp1 = *tail1;
		temp2 = temp2 -> prev;
	}
}