#include <stdio.h>
#include "apc.h"

int main(int argc, char *argv[])
{
    /* Declare the pointers */
    Dlist *head1 = NULL, *tail1 = NULL;
    Dlist *head2 = NULL, *tail2 = NULL;
    Dlist *headR1 = NULL, *tailR1 = NULL;
    Dlist *headR2 = NULL, *tailR2 = NULL;
    Dlist *headR = NULL, *tailR = NULL;

    if (argc < 4)
    {
        printf("Usage: ./a.out <num1> <operator> <num2>\n");
        return 1;
    }

    char operator= argv[2][0];
    int flag = 0; // Flag for subtraction

    switch (operator)
    {
    case '+':
        digit_to_list(&head1, &tail1, &head2, &tail2, argv);
        /* Call the function to perform the addition operation */
        addition(&head1, &tail1, &head2, &tail2, &headR, &tailR);
        printf("Result of Addition: ");
        print_list(&headR);
        break;

    case '-':
        swap(&head1, &tail1, &head2, &tail2, argv, &flag);
        /* Call the function to perform the subtraction operation */
        subtraction(&head1, &tail1, &head2, &tail2, &headR, &tailR, flag);
        printf("Result of Subtraction: ");
        print_list(&headR);
        break;

    case 'x':
        /* Call the function to perform the multiplication operation */
        digit_to_list(&head1, &tail1, &head2, &tail2, argv);
        multiplication(&head1, &tail1, &head2, &tail2, &headR1, &tailR1, &headR2, &tailR2);
        printf("Result of Multiplication: ");
        print_list(&headR1); // Assuming headR1 stores the final result
        break;

    case '/':
        // Call the function to perform the division operation 
        digit_to_list(&head1, &tail1, &head2, &tail2, argv);
        division(&head1, &tail1, &head2, &tail2, &headR, &tailR);
        break;

    default:
        printf("Invalid Input:-( Try again...\n");
    }

    // Cleanup: Free allocated memory 
    dl_delete_list(&head1, &tail1);
    dl_delete_list(&head2, &tail2);
    dl_delete_list(&headR, &tailR);

    return 0;
}
