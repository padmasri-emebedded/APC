#ifndef APC_H
#define APC_H
#include "apc.h"

#define SUCCESS 0
#define FAILURE -1

typedef struct node
{
	struct node *prev;
	int data;
	struct node *next;
}Dlist;

/*store the operands into the list */
int digit_to_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[]);

/*Addition */
int addition(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/*subtraction*/
int subtraction(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR, int flag);

/*Multiplication*/
int multiplication(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2, Dlist **headR1,Dlist **tailR1, Dlist **headR2,Dlist **tailR2);

/*Division */
int division(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/*Insert_at_last*/
int dl_insert_last(Dlist **head, Dlist **tail, int data);

/*Print list*/
void print_list(Dlist **head);

/*Insert at first*/
int dl_insert_first(Dlist **head, Dlist **tail, int data);

/* swap function */
int swap(Dlist **head1,Dlist **tail1, Dlist **head2, Dlist **tail2,char *argv[], int *flag);

/* Delete list */
int dl_delete_list(Dlist **head, Dlist **tail);

/* Multiplication part Addition */
int multiplication_addition(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR);

/* compare part of division.*/
int compare(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR,Dlist **tailR, char * argv[]);

/* Division part subraction */
int sub_div(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR);

/* Delete First */
int dl_delete_first(Dlist **head, Dlist **tail);

#endif
