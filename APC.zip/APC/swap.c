#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "apc.h"
/* Ensures correct operand order */
int swap(Dlist **head1,Dlist **tail1, Dlist **head2, Dlist **tail2, char *argv[], int *flag)
{
    char *str1 = argv[1];
    char *str2 = argv[3];
    int len1 = strlen(str1);
    int len2 = strlen(str2);

    if (len1 > len2) 
    {
        digit_to_list(head1, tail1, head2, tail2, argv);
    }
    else if (len1 < len2)
    {
        *flag = 1;
        int i = 0;
        while (argv[3][i] != '\0')
        {
            int data = argv[3][i] - '0';
            if (data >= 0 && data <= 9)
            {
                if (dl_insert_last(head1, tail1, data) == FAILURE)
                {
                    printf("INFO : Insert last Failure\n");
                }
                i++;
            }
            else
            {
                printf("\npassed argunments is not a digit.\n");
            }
        }
        i = 0;
        print_list(head1);
        while (argv[1][i] != '\0')
        {
            int data = argv[1][i] - '0';
            if (data >= 0 && data <= 9)
            {
                if (dl_insert_last(head2, tail2, data) == FAILURE)
                {
                    printf("INFO : Insert last Failure\n");
                }
                i++;
            }
            else
            {
                printf("\npassed argunments is not a digit.\n");
            }
        }
        i = 0;
        print_list(head2);
    }
    else
    {
        int result1 = strcmp(str1, str2);
        if (result1 == 0 || result1 > 0) 
        {
            digit_to_list(head1, tail1, head2, tail2, argv);
        } 
        else 
        {
            *flag = 1;
            int i = 0;
            while (argv[3][i] != '\0')
            {
                int data = argv[3][i] - '0';
                if (data >= 0 && data <= 9)
                {
                    if (dl_insert_last(head1, tail1, data) == FAILURE)
                    {
                        printf("INFO : Insert last Failure\n");
                    }
                    i++;
                }
                else
                {
                    printf("\npassed argunments is not a digit.\n");
                }
            }
            print_list(head1);
            int  j = 0;
            while (argv[1][j] != '\0')
            {
                int data = argv[1][j] - '0';
                if (data >= 0 && data <= 9)
                {
                    if (dl_insert_last(head2, tail2, data) == FAILURE)
                    {
                        printf("INFO : Insert last Failure\n");
                    }
                    j++;
                }
                else
                {
                    printf("\npassed argunments is not a digit.\n");
                }
            }
            print_list(head2);
        } 
         
    }
}