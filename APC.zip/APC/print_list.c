#include <stdio.h>
#include <stdlib.h>
#include "apc.h"

void print_list(Dlist **head)
{
	/* Cheking the list is empty or not */
	Dlist *temp=*head;
	if (*head == NULL)
	{
		printf("INFO : List is empty\n");
	}
	else
	{
	    while (temp)		
	    {
		    /* Printing the list */
		    printf("%d", (temp) -> data);

		    /* Travering in forward direction */
		   temp = (temp) -> next;
	    }

    }
	printf("\n");
}