#include <stdio.h>
#include <stdlib.h>
#include "apc.h"
/* Called in main.c to store user input as a DLL */
int digit_to_list(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,char *argv[])
{
    int i = 0;
    while (argv[1][i] != '\0')
    {
        int data = argv[1][i] - '0';
        if (data >= 0 && data <= 9)
        {
            if (dl_insert_last(head1, tail1, data) == FAILURE)
            {
                printf("INFO : Insert last Failure\n");
            }
            i++;
        }
        else
        {
            printf("\npassed argunments is not a digit.\n");
        }
    }
    print_list(head1);
    int  j = 0;
    while (argv[3][j] != '\0')
    {
        int data = argv[3][j] - '0';
        if (data >= 0 && data <= 9)
        {
            if (dl_insert_last(head2, tail2, data) == FAILURE)
            {
                printf("INFO : Insert last Failure\n");
            }
            j++;
        }
        else
        {
            printf("\npassed argunments is not a digit.\n");
        }
    }
    print_list(head2);
}