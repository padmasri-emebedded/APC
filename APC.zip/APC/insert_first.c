#include <stdio.h>
#include <stdlib.h>
#include "apc.h"

int dl_insert_first(Dlist **head, Dlist **tail, int data)
{
    Dlist *new = malloc(sizeof(Dlist)); //to creat memory
    if(new == NULL) // to check the list is empty or not.
    {
        return FAILURE;
    }
    new -> data = data; 
    new -> next = *head;
    new -> prev = NULL;
    if(*head == NULL)
    {
        *head = new;
        *tail = new;
        return SUCCESS;
    }
    (*head) -> prev = new;
    *head = new;
    return SUCCESS;
}