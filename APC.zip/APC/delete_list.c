#include "apc.h"
#include<stdio.h>
#include<stdlib.h>
/* Used for memory cleanup */
int dl_delete_list(Dlist **head, Dlist **tail)
{
    if (*head == NULL) // Check if the list is empty
    {
        return FAILURE;
    }

    while (*head != NULL) // Free all nodes one by one
    {
        Dlist *temp = *head;     // Store the current head node
        *head = (*head)->next;  // Move head to the next node
        free(temp);             // Free the current node
    }

    *tail = NULL; // Reset tail after clearing all nodes
    return SUCCESS;
}