#include "apc.h"
#include <stdio.h>
#include <string.h>
/* Used in division logic */
int compare(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR, char *argv[])
{
    char *str1 = argv[1];
    char *str2 = argv[3];
    int len1 = strlen(str1);
    int len2 = strlen(str2);

    if (len1 > len2) 
    {
        digit_to_list(head1, tail1, head2, tail2, argv);
    } 
    else if (len1 < len2) 
    {
        dl_insert_first(headR, tailR, 0);
    }
    else 
    {
        if (strcmp(str1, str2) <= 0) 
        {
            dl_insert_first(headR, tailR, 0);
        } 
        else 
        {
            digit_to_list(head1, tail1, head2, tail2, argv);
        }
    }
 }