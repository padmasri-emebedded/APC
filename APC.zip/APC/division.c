#include <stdio.h>
#include <stdlib.h>
#include "apc.h"
int count = 0;
int division_compare(Dlist *head1, Dlist *head2)
{
    Dlist *temp1 = head1;
    Dlist *temp2 = head2;
    int Count1 = 0, Count2 = 0;

    while (temp1 != NULL)
    {
        Count1++;
        temp1 = temp1->next;
    }
    while (temp2 != NULL)
    {
        Count2++;
        temp2 = temp2->next;
    }

    if (Count1 > Count2)
    {
        return SUCCESS;
    }
    else if (Count1 < Count2)
    {
        return FAILURE;
    }

    temp1 = head1;
    temp2 = head2;
    while (temp1 && temp2)
    {
        if (temp1->data > temp2->data)
        {
            return SUCCESS;
        }
        else if (temp1->data < temp2->data)
        {
            return FAILURE;
        }
        temp1 = temp1->next;
        temp2 = temp2->next;
    }
    return 0; // Numbers are equal
}

/*
    Function: division()
    Purpose: Performs division using repeated subtraction.
*/
int division(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    if ((*headR) != NULL)
    {
        print_list(headR);
    }
    else
    {
        while ((division_compare(*head1, *head2)) >= 0)
        {
            sub_div(head1, tail1, head2, tail2, headR, tailR);
            count++;
            dl_delete_list(head1, tail1);
            *head1 = *headR;
            *tail1 = *tailR;
            *headR = NULL;
            *tailR = NULL;
        }
    }
    printf("Result of Division: %d\n", count);

    return SUCCESS;
}
/*
    Function: sub_div()
    Purpose: Performs subtraction as part of division logic.
*/

int sub_div(Dlist **head1, Dlist **tail1, Dlist **head2, Dlist **tail2, Dlist **headR, Dlist **tailR)
{
    Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int borrow = 0, num1 = 0, num2 = 0, result = 0;

    while (temp1 != NULL || temp2 != NULL)
    {
        if (temp1 != NULL)
        {
            num1 = temp1->data;
            temp1 = temp1->prev;
        }
        else
        {
            num1 = 0;
        }

        if (temp2 != NULL)
        {
            num2 = temp2->data;
            temp2 = temp2->prev;
        }
        else
        {
            num2 = 0;
        }

        num1 -= borrow;

        if (num1 < num2)
        {
            result = (num1 + 10) - num2;
            borrow = 1;
        }
        else
        {
            result = num1 - num2;
            borrow = 0;
        }

        if (dl_insert_first(headR, tailR, result) == FAILURE)
        {
            printf("Error: Insertion failed during subtraction.\n");
            return FAILURE;
        }
    }

    while (*headR != NULL && (*headR)->data == 0 && (*headR)->next != NULL)
    {
        dl_delete_first(headR, tailR);
    }

    return SUCCESS;
}
