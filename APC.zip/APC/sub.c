#include "apc.h"
#include <stdio.h>
#include <stdlib.h>
/* Called when '-' operator is used */
int subtraction(Dlist **head1,Dlist **tail1,Dlist **head2,Dlist **tail2,Dlist **headR,Dlist **tailR, int flag)
{
	Dlist *temp1 = *tail1;
    Dlist *temp2 = *tail2;

    int borrow = 0, num1 = 0, num2 = 0, result = 0;

    while (temp1 != NULL || temp2 != NULL)
    {
        if (temp1 != NULL)
        {
            num1 = temp1->data;
            temp1 = temp1->prev;
        }
        else
        {
            num1 = 0;
        }

        if (temp2 != NULL)
        {
            num2 = temp2->data;
            temp2 = temp2->prev;
        }
        else
        {
            num2 = 0;
        }

        num1 -= borrow;

        if (num1 < num2)
        {
            result = (num1 + 10) - num2;
            borrow = 1;
        }
        else
        {
            result = num1 - num2;
            borrow = 0;
        }

        if (dl_insert_first(headR, tailR, result) == FAILURE)
        {
            printf("Error: Insertion failed during subtraction.\n");
            return FAILURE;
        }
    }

    while (*headR != NULL && (*headR)->data == 0 && (*headR)->next != NULL)
    {
        dl_delete_first(headR, tailR);
    }

    return SUCCESS;
}
